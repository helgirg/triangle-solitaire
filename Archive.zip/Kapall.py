
#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import Tkinter
from Tkinter import *
from Canvas import Rectangle, CanvasText, Group, Window
from Gui import *
import random
import time

class Group(Group):
    def bind(self, sequence=None, command=None):
        return self.canvas.tag_bind(self.id, sequence, command)

# self = Tkinter.Tk()
# C = Tkinter.Canvas(self, bg="forest green", height=650, width=1000)

# self.title ("Pyramida kapall")
# C.pack()
# self.mainloop()

card_width = 126
card_height = 50   

class Kapall():

    def __init__(self):
        self.deck=[]
        gildi_spila = []

        

    def newdeck(self):
        self.deck = ['AS', 'KS', 'QS', 'JS', '10S', '9S', '8S', '7S', '6S', '5S', '4S', '3S', '2S',\
                        'AT', 'KT', 'QT', 'JT', '10T', '9T', '8T', '7T', '6T', '5T', '4T', '3T', '2T',\
                        'AL', 'KL', 'QL', 'JL', '10L', '9L', '8L', '7L', '6L', '5L', '4L', '3L', '2L',\
                        'AH', 'KH', 'QH', 'JH', '10H', '9H', '8H', '7H', '6H', '5H', '4H', '3H', '2H']
        
    def shuffle(self):
        random.shuffle(self.deck)
        print self.deck

    #Gefa hverju spili gildi fyrir samlagningu
    def gildi(tala):
        gildi_spila = {'AS':1, 'KS':13, 'QS':12, 'JS':11, '10S':10, '9S':9, '8S':8, '7S':7, '6S':6, '5S':5, '4S':4, '3S':3, '2S':2,\
        'AT':1, 'KT':13, 'QT':12, 'JT':11, '10T':10, '9T':9, '8T':8, '7T':7, '6T':6, '5T':5, '4T':4, '3T':3, '2T':2,\
        'AL':1, 'KL':13, 'QL':12, 'JL':11, '10L':10, '9L':9, '8L':8, '7L':7, '6L':6, '5L':5, '4L':4, '3L':3, '2L':2,\
        'AH':1, 'KH':13, 'QH':12, 'JH':11, '10H':10, '9H':9, '8H':8, '7H':7, '6H':6, '5H':5, '4H':4, '3H':3, '2H':2}
    
    def teikna_kapal(self):
        self = Tkinter.Tk()
        C = Tkinter.Canvas(self, bg="forest green", height=650, width=1000)
        C.create_rectangle(50,50,126,146,fill="red")
        photo = PhotoImage(file="Deck2.gif")
        image = C.create_image (card_width,card_height, anchor =NE, image = photo)
        self.title ("Pyramida kapall")
        C.pack()
        self.mainloop()
        # create the Gui and the Canvas
        g = Gui()
        ca = g.ca(width=500, height=500, bg='white')

        def make_circle(event= None):
            """Makes a circle item at the location of a button press."""
            print "hallo ballo"
            pos = ca.canvas_coords([event.x, event.y])
            item = ca.circle(pos, 5, fill='red')
            item = Draggable(item)

        ca.bind('<ButtonPress-2>', make_circle)

        g.mainloop()
        C.pack()
        self.mainloop()

class Draggable(Item):
    """A Canvas Item with bindings for dragging and dropping.

    Given an item, Draggable(item) creates bindings and returns
    a Draggable object with the same canvas and tag as the original.
    """
    def __init__(self, item):
        self.canvas = item.canvas
        self.tag = item.tag
        self.bind('<ButtonPress-1>', self.select)
        self.bind('<B1-Motion>', self.drag)
        self.bind('<ButtonRelease-1>', self.drop)

    # the following event handlers take an event object as a parameter

    def select(self, event):
        """Selects this item for dragging."""
        self.dragx = event.x
        self.dragy = event.y

        self.fill = self.cget('fill')
        self.config(fill='orange')
        
    def drag(self, event):
        """Move this item using the pixel coordinates in the event object."""
        # see how far we have moved
        dx = event.x - self.dragx
        dy = event.y - self.dragy

        # save the current drag coordinates
        self.dragx = event.x
        self.dragy = event.y

        # move the item 
        self.move(dx, dy)

    def drop(self, event):
        """Drops this item."""
        self.config(fill=self.fill)





    