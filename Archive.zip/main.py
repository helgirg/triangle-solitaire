from Kapall import *
import itertools
import random

d = Kapall()
d.newdeck()
d.teikna_kapal()
